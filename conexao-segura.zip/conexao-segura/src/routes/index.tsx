import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Conexão Segura — O Jogo" },
      { name: "description", content: "Jogo educativo sobre segurança na internet com narração animada para crianças." },
      { property: "og:title", content: "Conexão Segura — O Jogo" },
      { property: "og:description", content: "Jogue, aprenda a se proteger na internet e ganhe moedas." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  useEffect(() => {
    window.location.replace("/jogo/index.html");
  }, []);
  return (
    <div className="flex min-h-screen items-center justify-center bg-background text-foreground">
      <a href="/jogo/index.html">Abrir o jogo Conexão Segura</a>
    </div>
  );
}
