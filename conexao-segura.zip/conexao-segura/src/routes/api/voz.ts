import { createFileRoute } from "@tanstack/react-router";

const MODEL = "google/gemini-3.1-flash-tts-preview";
const VOICE = "Leda"; // jovem e alegre

export const Route = createFileRoute("/api/voz")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let text = "";
        try {
          const body = (await request.json()) as { text?: unknown };
          text = typeof body.text === "string" ? body.text.trim() : "";
        } catch {
          return Response.json({ erro: "JSON inválido." }, { status: 400 });
        }
        if (!text || text.length > 600) {
          return Response.json({ erro: "Texto inválido." }, { status: 400 });
        }
        const key = process.env["LOVABLE_API_KEY"];
        if (!key) return Response.json({ erro: "Voz não configurada." }, { status: 500 });

        const prompt =
          "Leia em português do Brasil com a voz de uma criança personagem de desenho animado: " +
          "bem animada, alegre, expressiva, sorridente e brincalhona, com entonação viva e natural, " +
          "nada robótica. Texto: " +
          text;

        const res = await fetch("https://ai.gateway.lovable.dev/v1/audio/speech", {
          method: "POST",
          headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            model: MODEL,
            contents: [{ role: "user", parts: [{ text: prompt }] }],
            generationConfig: {
              responseModalities: ["AUDIO"],
              speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: VOICE } } },
            },
          }),
        });
        if (!res.ok) {
          const detail = await res.text().catch(() => "");
          return new Response(detail || JSON.stringify({ erro: "Falha na voz." }), {
            status: res.status,
            headers: { "Content-Type": "application/json" },
          });
        }
        return new Response(res.body, {
          headers: {
            "Content-Type": res.headers.get("content-type") || "audio/wav",
            "Cache-Control": "no-store",
          },
        });
      },
    },
  },
});
